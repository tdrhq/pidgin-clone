#define GAIM_PLUGINS
#include "multi.h"
#include "gaim.h"
#include "pixmaps/ok.xpm"
#include "pixmaps/cancel.xpm"

static GtkWidget *idlewin = NULL;
static int maxnum = 10;

char *name() {
	return "Convo Limiter";
}

char *description() {
	return "Allows you to limit max # of conversations";
}

static void im_handler(struct gaim_connection *gc, char *who, char **text, void *data) {
	if (find_conversation(who))
		return;
	if (g_list_length(conversations) >= maxnum) {
		serv_send_im(gc, who, "Already engaged in Maximum # of conversations, please try again later.", 1);
		g_free(*text);
		*text = NULL;
	}
}

char *gaim_plugin_init(GModule *module) {
	gaim_signal_connect(module, event_im_recv, im_handler, NULL);
	return NULL;
}

static void des_idle_win(GtkWidget *win, gpointer data) {
	gtk_widget_destroy(idlewin);
	idlewin = NULL;
}

static void set_idle(GtkWidget *button, GtkWidget *spinner) {
	maxnum = CLAMP(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner)), 0, G_MAXINT);
	des_idle_win(idlewin, NULL);
}

static void unset_idle(GtkWidget *button, GtkWidget *spinner) {
	des_idle_win(idlewin, NULL);
}

char *gaim_plugin_config() {
	GtkWidget *frame;
	GtkWidget *vbox;
	GtkWidget *hbox;
	GtkWidget *label;
	GtkAdjustment *adj;
	GtkWidget *spinner;
	GtkWidget *button;

	if (idlewin) {
		gtk_widget_show(idlewin);
		return;
	}

	idlewin = gtk_window_new(GTK_WINDOW_DIALOG);
	gtk_window_set_title(GTK_WINDOW(idlewin), "Idle Time");
	gtk_window_set_policy(GTK_WINDOW(idlewin), 0, 0, 1);
	gtk_window_set_wmclass(GTK_WINDOW(idlewin), "idle", "gaim");
	gtk_widget_realize(idlewin);
	aol_icon(idlewin->window);
	gtk_signal_connect(GTK_OBJECT(idlewin), "destroy",
			   GTK_SIGNAL_FUNC(des_idle_win), NULL);

	frame = gtk_frame_new("Idle Time");
	gtk_container_add(GTK_CONTAINER(idlewin), frame);

	vbox = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(frame), vbox);

	hbox = gtk_hbox_new(FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

	label = gtk_label_new("idle for");
	gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);

	adj = (GtkAdjustment *)gtk_adjustment_new(10, 0, G_MAXINT, 1, 0, 0);
	spinner = gtk_spin_button_new(adj, 0, 0);
	gtk_box_pack_start(GTK_BOX(hbox), spinner, TRUE, TRUE, 0);

	label = gtk_label_new("minutes.");
	gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);

	hbox = gtk_hbox_new(TRUE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

	button = picture_button(idlewin, _("Set"), ok_xpm);
	gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 5);
	gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(set_idle), spinner);

	button = picture_button(idlewin, _("Cancel"), cancel_xpm);
	gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 5);
	gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(unset_idle), spinner);

	gtk_widget_show_all(idlewin);
}

void gaim_plugin_remove() {
	if (idlewin)
		gtk_widget_destroy(idlewin);
	idlewin = NULL;
}
