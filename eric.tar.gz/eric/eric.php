<?
	$x = fopen("m.c", "r+");
	if ($x) {
		echo "open";
		fclose($x);
	} else {
		echo "not";
	}
?>
