#define GAIM_PLUGINS
#include "gaim.h"

char *name()
{
    return "Auto-Add";
}

char *description()
{
    return "Automatically add people to your buddy list when they send you a message.";
}

static void im_handler(struct gaim_connection *gc, char **who, char **text, void *data)
{
	add_buddy(gc, "New Users", *who, *who);
}

char *gaim_plugin_init(GModule *h)
{
	gaim_signal_connect(h, event_im_send, im_handler, NULL);
	return NULL;
}
