for i in icq irc jabber msn napster oscar toc yahoo zephyr
do
	echo -n $i:
	grep g\[td\]k $i/*.c | wc -l
done
