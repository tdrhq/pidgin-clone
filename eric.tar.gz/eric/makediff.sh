rm -f gaim.diff
for i in *.[ch] ; do diff -u ../../../icqlib/icqlib/$i $i >>gaim.diff 2>/dev/null ; done
