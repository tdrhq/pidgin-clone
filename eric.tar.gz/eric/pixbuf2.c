#include <gdk-pixbuf/gdk-pixbuf.h>
#include <gdk-pixbuf/gdk-pixbuf-loader.h>
#include <gtk/gtk.h>
#include <stdio.h>

char data[8192];
int length;

void des_evt(GtkObject *o, gpointer d)
{
	gtk_main_quit();
}

int main(int argc, char **argv)
{
	GdkPixbufLoader *load;
	GdkPixbufAnimation *anim;
	GdkPixbuf *unanim;
	char data[8192];
	int length;

	FILE *f;
	GtkWidget *win;
	GtkWidget *pix;

	gtk_init(&argc, &argv);

	if (argc == 2)
		f = fopen(argv[1], "r");
	else
		f = fopen("picture.id", "r");
	if (!f) return 1;

	length = fread(data, 1, 8192, f);
	fclose(f);

	load = gdk_pixbuf_loader_new();
	gdk_pixbuf_loader_write(load, data, length, NULL);
	anim = gdk_pixbuf_loader_get_animation(load);

	if (anim) {
		pix = gtk_image_new_from_animation(anim);
		gdk_pixbuf_animation_unref(anim);
	} else {
		unanim = gdk_pixbuf_loader_get_pixbuf(load);
		pix = gtk_image_new_from_pixbuf(unanim);
		gdk_pixbuf_unref(unanim);
	}

	win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_policy(GTK_WINDOW(win), TRUE, TRUE, TRUE);
	gtk_signal_connect(GTK_OBJECT(win), "destroy", GTK_SIGNAL_FUNC(des_evt), NULL);

	gtk_container_add(GTK_CONTAINER(win), pix);
	gtk_widget_show(pix);

	gdk_pixbuf_loader_close(load, NULL);

	gtk_widget_show(win);

	gtk_main();

	return 0;
}
