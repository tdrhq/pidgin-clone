Index: src/protocols/icq/icqpacket.c
===================================================================
RCS file: /cvsroot/gaim/gaim/src/protocols/icq/icqpacket.c,v
retrieving revision 1.1
diff -u -r1.1 icqpacket.c
--- src/protocols/icq/icqpacket.c	2001/07/31 01:00:38	1.1
+++ src/protocols/icq/icqpacket.c	2001/09/06 14:39:08
@@ -59,7 +59,8 @@
 {
   DWORD val=i;
 
-  *(unsigned long*)((p->data)+(p->cursor))=htoicql(val);
+  val = htoicql(val);
+  memcpy((p->data)+(p->cursor),&val,sizeof(DWORD));
   icq_PacketAdvance(p, sizeof(DWORD));
 }
 
@@ -67,7 +68,7 @@
 {
   DWORD val=i;
 
-  *(DWORD *)((p->data)+(p->cursor)) = val;
+  memcpy((p->data)+(p->cursor),&val,sizeof(DWORD));
   icq_PacketAdvance(p, sizeof(DWORD));
 }
 
@@ -75,7 +76,8 @@
 {
   DWORD val;
 
-  val = icqtohl(*(DWORD *)((p->data)+(p->cursor)));
+  memcpy(&val,(p->data)+(p->cursor),sizeof(DWORD));
+  val = icqtohl(val);
   icq_PacketAdvance(p, sizeof(DWORD));
 
   return val;
@@ -85,7 +87,7 @@
 {
   DWORD val;
 
-  val = *(DWORD*)((p->data)+(p->cursor));
+  memcpy(&val,(p->data)+(p->cursor),sizeof(DWORD));
   icq_PacketAdvance(p, sizeof(DWORD));
 
   return val;
@@ -95,7 +97,8 @@
 {
   WORD val=i;
 
-  *(WORD *)((p->data)+(p->cursor)) = htoicqs(val);
+  val = htoicqs(val);
+  memcpy((p->data)+(p->cursor),&val,sizeof(WORD));
   icq_PacketAdvance(p, sizeof(WORD));
 }
 
@@ -103,7 +106,7 @@
 {
   WORD val=i;
 
-  *(WORD *)((p->data)+(p->cursor)) = val;
+  memcpy((p->data)+(p->cursor),&val,sizeof(WORD));
   icq_PacketAdvance(p, sizeof(WORD));
 }
 
@@ -111,7 +114,8 @@
 {
   WORD val;
 
-  val = icqtohs(*(WORD *)((p->data)+(p->cursor)));
+  memcpy(&val,(p->data)+(p->cursor),sizeof(WORD));
+  val = icqtohs(val);
   icq_PacketAdvance(p, sizeof(WORD));
 
   return val;
@@ -121,7 +125,7 @@
 {
   WORD val;
 
-  val = *(WORD*)((p->data)+(p->cursor));
+  memcpy(&val,(p->data)+(p->cursor),sizeof(WORD));
   icq_PacketAdvance(p, sizeof(WORD));
 
   return val;
Index: src/protocols/icq/udp.c
===================================================================
RCS file: /cvsroot/gaim/gaim/src/protocols/icq/udp.c,v
retrieving revision 1.1
diff -u -r1.1 udp.c
--- src/protocols/icq/udp.c	2001/07/31 01:00:38	1.1
+++ src/protocols/icq/udp.c	2001/09/06 14:39:08
@@ -108,10 +108,12 @@
   DWORD checkcode = icq_UDPCalculateCheckCode(p);
   DWORD code1, code2, code3;
   DWORD pos;
+  DWORD tmp;
 
   memcpy(buffer, p->data, p->length);
 
-  *(DWORD *)(buffer+0x14)=htoicql(checkcode);
+  tmp = htoicql(checkcode);
+  memcpy((buffer+0x14),&tmp,sizeof(DWORD));
   code1 = p->length * 0x68656c6cL;
   code2 = code1 + checkcode;
   pos = 0x0A;
@@ -121,10 +123,12 @@
     DWORD data = icqtohl(*(DWORD *)((p->data)+pos));
     code3 = code2 + icq_UDPTable[pos & 0xFF];
     data ^= code3;
-    *(DWORD*)(buffer+pos)=htoicql(data);
+    data = htoicql(data);
+    memcpy((buffer+pos),&data,sizeof(DWORD));
   }
   checkcode = icq_UDPScramble(checkcode);
-  *(DWORD *)(buffer+0x14)=htoicql(checkcode);
+  tmp = htoicql(checkcode);
+  memcpy((buffer+0x14),&tmp,sizeof(DWORD));
 }
 
 /*********************************************************
