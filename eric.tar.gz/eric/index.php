<?php
	require "base.inc.php";

	start_html("Eric's Page");

	start_section("Plugins");
?>
<P><B>June 6, 2001: </b><a href="idle.c">Plugin</a> to set the idle time
for an account.
</p>

<p><b>September 6, 2001: </b><a href="autoadd.c">Plugin</a> to automatically add
people to your buddy list when they IM you.
</p>

<p><b>September 6, 2001: </b><a href="maxconvo.c">Plugin</a> to limit the number
of conversation windows.
</p>
<?php end_section() ?>

<?php start_section("Patches") ?>
<p><b>June 6, 2001: </b><a href="gtk2.php">Directions</a> for getting
Gaim to compile using <a href="http://www.gtk.org/">GTK 2</a> (still in CVS)
</p>

<p><b>June 9, 2001: </b><a href="gaim.diff">Diff</a> against icqlib from CVS and
<a href="makediff.sh">script</a> I use to make the diff. Very me-specific. I
don't know why I'm posting this.
</p>

<p><b>June 9, 2001: </b><a href="mid.diff">Patch</a> I made for mid so that he
could have the conversation tabs and chat tabs in the buddy list. Very buggy but
mostly functional.
</p>

<p><b>August 28, 2001: </b><a href="gendiff.sh">Script</a> to generate the diffs
between icqlib and libfaim and gaim's copy of them. I don't know why I'm posting
this.
</p>

<p><b>August 29, 2001: </b><a href="broken2.diff">New diff</a> for getting gaim
to work with GTK 2. --enable-gtk2, otherwise it'll use GTK 1.2. No guarantees
about it compiling.
</p>

<p><b>September 5, 2001: </b><a href="tricks.php">Tricks</a> that you can do
by modifying gaim's source.
</p>

<p><b>December 8, 2001: </b><a href="whatfont.diff">Patch</a> for gtkimhtml.c that
prints some debugging messages about what fonts are being tried/used in the
conversation display.
</p>
<?php end_section() ?>

<?php start_section("Other") ?>
<p><b>June 6, 2001: </b><a href="base64.c">Base64</a> converter. Copied
from Gaim code to bug test it.
</p>

<p><b>June 6, 2001: </b><a href="pixbuf.php">GdkPixbuf</a> tests that
I did (with sample animations too, thanks mid and elnscott).
</p>

<p><b>June 14, 2001: </b><a href="design.txt">Design ideas</a> for what Gaim
might be like in the future.
</p>

<p><b>July 26, 2001: </b><a href="gaim-0.12.0pre20010725.tar.gz">Gaim
0.12.0pre20010725 tarball</a> for a quick look at some implementation ideas for
a future gaim.
</p>

<p><b>July 26, 2001: </b><a href="roadmap.txt">Roadmap</a> for where I'd like to
see 0.11 and 0.12 go.
</p>
<?php end_section() ?>

<?php
	end_html();
?>
