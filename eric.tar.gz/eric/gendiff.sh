cd /usr/local/src/gaim/libfaim/src
for i in *.c ; do
	diff -Nu --ignore-matching-lines=\\\$Id: gendiff.sh 3629 2002-09-26 10:21:44Z chipx86 $ $i ../../app/src/protocols/oscar/$i
done

cd /usr/local/src/gaim/libfaim/include
for i in *.h ; do
	diff -Nu --ignore-matching-lines=\\\$Id: gendiff.sh 3629 2002-09-26 10:21:44Z chipx86 $ $i ../../app/src/protocols/oscar/$i
done

cd /usr/local/src/gaim/icqlib/icqlib
for i in *.c ; do
	diff -Nu --ignore-matching-lines=\\\$Id: gendiff.sh 3629 2002-09-26 10:21:44Z chipx86 $ $i ../../app/src/protocols/icq/$i
done

cd /usr/local/src/gaim/icqlib/icqlib
for i in *.h ; do
	diff -Nu --ignore-matching-lines=\\\$Id: gendiff.sh 3629 2002-09-26 10:21:44Z chipx86 $ $i ../../app/src/protocols/icq/$i
done
