/* a nifty little plugin to set your idle time to whatever you want it to be.
 * useful for almost nothing. mostly just a demo plugin. but it's fun to have
 * 40-day idle times.
 */

#define GAIM_PLUGINS
#include "multi.h"
#include "gaim.h"
#include <sys/time.h>
#include "pixmaps/ok.xpm"
#include "pixmaps/cancel.xpm"

static GtkWidget *idlewin = NULL;
static struct gaim_connection *gc = NULL;

char *name() {
	return "I'dle Mak'er";
}

char *description() {
	return "Allows you to hand-configure how long you've been idle for";
}

char *gaim_plugin_init(GModule *module) {
	return NULL;
}

static void des_idle_win(GtkWidget *win, gpointer data) {
	gtk_widget_destroy(idlewin);
	idlewin = NULL;
}

static void set_idle(GtkWidget *button, GtkWidget *spinner) {
	time_t t;
	int tm = CLAMP(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner)), 0, G_MAXINT);
	if (!gc) {
		des_idle_win(idlewin, NULL);
		return;
	}
	debug_printf("setting idle time for %s to %d\n", gc->username, tm);
	time(&t);
	t -= 60 * tm;
	gc->lastsent = t;
	serv_set_idle(gc, 60 * tm);
	gc->is_idle = 0;
	des_idle_win(idlewin, NULL);
}

static void unset_idle(GtkWidget *button, GtkWidget *spinner) {
	des_idle_win(idlewin, NULL);
}

static void sel_gc(GtkWidget *opt, struct gaim_connection *g) {
	gc = g;
}

static void make_connect_menu(GtkWidget *box) {
	GtkWidget *optmenu, *menu, *opt;
	GSList *c = connections;
	struct gaim_connection *g;

	optmenu = gtk_option_menu_new();
	gtk_box_pack_start(GTK_BOX(box), optmenu, FALSE, FALSE, 5);

	menu = gtk_menu_new();

	while (c) {
		g = (struct gaim_connection *)c->data;
		opt = gtk_menu_item_new_with_label(g->username);
		gtk_signal_connect(GTK_OBJECT(opt), "activate",
				   GTK_SIGNAL_FUNC(sel_gc), g);
		gtk_menu_append(GTK_MENU(menu), opt);
		gtk_widget_show(opt);
		c = g_slist_next(c);
	}

	gtk_option_menu_remove_menu(GTK_OPTION_MENU(optmenu));
	gtk_option_menu_set_menu(GTK_OPTION_MENU(optmenu), menu);
	gtk_option_menu_set_history(GTK_OPTION_MENU(optmenu), 0);

	if (connections)
		gc = connections->data;
	else
		gc = NULL;
}

char *gaim_plugin_config() {
	GtkWidget *frame;
	GtkWidget *vbox;
	GtkWidget *hbox;
	GtkWidget *label;
	GtkAdjustment *adj;
	GtkWidget *spinner;
	GtkWidget *button;

	if (idlewin) {
		gtk_widget_show(idlewin);
		return;
	}

	idlewin = gtk_window_new(GTK_WINDOW_DIALOG);
	gtk_window_set_title(GTK_WINDOW(idlewin), "Idle Time");
	gtk_window_set_policy(GTK_WINDOW(idlewin), 0, 0, 1);
	gtk_window_set_wmclass(GTK_WINDOW(idlewin), "idle", "gaim");
	gtk_widget_realize(idlewin);
	aol_icon(idlewin->window);
	gtk_signal_connect(GTK_OBJECT(idlewin), "destroy",
			   GTK_SIGNAL_FUNC(des_idle_win), NULL);

	frame = gtk_frame_new("Idle Time");
	gtk_container_add(GTK_CONTAINER(idlewin), frame);

	vbox = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(frame), vbox);

	hbox = gtk_hbox_new(FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

	label = gtk_label_new("Set");
	gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);

	make_connect_menu(hbox);

	label = gtk_label_new("idle for");
	gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);

	adj = (GtkAdjustment *)gtk_adjustment_new(10, 0, G_MAXINT, 1, 0, 0);
	spinner = gtk_spin_button_new(adj, 0, 0);
	gtk_box_pack_start(GTK_BOX(hbox), spinner, TRUE, TRUE, 0);

	label = gtk_label_new("minutes.");
	gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);

	hbox = gtk_hbox_new(TRUE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

	button = picture_button(idlewin, _("Set"), ok_xpm);
	gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 5);
	gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(set_idle), spinner);

	button = picture_button(idlewin, _("Cancel"), cancel_xpm);
	gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 5);
	gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(unset_idle), spinner);

	gtk_widget_show_all(idlewin);
}

void gaim_plugin_remove() {
	if (idlewin)
		gtk_widget_destroy(idlewin);
	idlewin = NULL;
}
