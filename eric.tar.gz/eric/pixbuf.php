<?php
	require "base.inc.php";

	start_html("GdkPixbuf Tests");

	start_section("GdkPixbuf Tests");
?>
<p>
 When I was adding buddy icons to Gaim I wrote a quick test program that
 used GdkPixbuf. You can get a copy of that program <a href="pixbuf.c">here</a>.
 To compile it, run:
</p>

<p>
 <code>gcc -o pixbuf pixbuf.c `gdk-pixbuf-config --cflags` `gdk-pixbuf-config --libs`</code>
</p>

<p>
 Well, as it turns out, it doesn't display the following images very well:
</p>

<p>
 <img src="ABpenguinsAIM.gif" alt="animated penguins" />
 <img src="bf.gif" alt="butterfly" />
 <img src="ABcherrychopAIM.gif" alt="chopping down a tree" />
</p>

<p>
 So I wrote another quick test program to test GTK 2. You can get a copy
 of that program <a href="pixbuf2.c">here</a>. To compile it, run:
</p>

<p>
 <code>gcc -o pixbuf2 pixbuf2.c `pkg-config gtk+-x11-2.0 --cflags` `pkg-config gtk+-x11-2.0 --libs`</code>
</p>

<p>
 Turns out I actually didn't need to write it because there's a testanimation
 program in the GTK 2 source that does exactly the same thing. Oh well. Anyway,
 if you compare the two you'll see that it's much easier to code and displays
 better. Such is the power of GTK 2.
</p>
<?php end_section() ?>

<?php
	end_html();
?>
