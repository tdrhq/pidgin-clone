<?php
	require "base.inc.php";

	start_html("Cool Gaim Tricks");

	start_section("Reversing the conversation colors");
?>
<p>
 If you're used to WinAIM and want the color of the name on incoming messages
 to be blue instead of red, here's how you change them. In conversation.c, in the
 function write_to_conv around line 1400, is a set of statements:
</p>

<p>
<pre>if (flags &amp; WFLAG_RECV)
	strcpy(colour, "#ff0000");
else if (flags &amp; WFLAG_SEND)
	strcpy(colour, "#0000ff");
</pre>
</p>

<p>
 Just switch the two strcpy lines.
</p>
<?php end_section() ?>

<?php start_section("Hiding MemberSince") ?>
<p>
 In Oscar, you can hide how long you've been a member since by removing one
 flag. In src/protocols/oscar/oscar.c, in gaim_rateresp, is a call to
 aim_bos_setprivacyflags. Just remove the AIM_PRIVFLAGS_ALLOWMEMBERSINCE from
 there. You can also hide idle time at a protocol level that way (there's an
 AIM_PRIVFLAGS_ALLOWIDLE flag).
</p>
<?php end_section() ?>

<?php start_section("Blocking AOL Users") ?>
<p>
 If you want to make it so only people using AOL can't see you (again, only if
 you're using Oscar), in gaim_rateresp, there's a call to aim_bos_setgroupperm.
 Change it from AIM_FLAG_ALLUSERS to AIM_FLAG_ALLUSERS ^ AIM_FLAG_AOL. Similarly,
 to block everyone who isn't an AOL user, change it to just AIM_FLAG_AOL.
</p>
<?php end_section() ?>

<?php start_section("Control your limits") ?>
<p>
 You can specify the largest message you can receive, and how often you can
 receive them. In src/protocols/oscar/oscar.c, in gaim_icbm_param_info, change
 params-&gt;maxmsglen to the largest message you want to be able to receive.
 params-&gt;minmsginterval is the minimum number of milliseconds between messages.
 That is, if you don't want large messages and you don't want to get flooded,
 change these to 2000 and 2000. You'll only be able to receive messages 2000
 characters long, once every two seconds.  (Incidentally, this is most likely
 what the TOC server does to limit messages to TOC users to 4k chars.)
</p>
<?php end_section() ?>
<?php
	end_html();
?>
