<?php
	require "base.inc.php";

	start_html("Gtk 2.0");

	start_section("Introduction");
?>
<p>
 GTK 2 is supposed to be released at the end of June or maybe in July sometime.
 So I figured I should probably get off my lazy ass and see how hard it was going
 to be to port Gaim to GTK 2.
</p>

<p>
 If I take the easy way, it turns out to be rather easy. 700-line <a
 href="broken.diff">diff</a> easy, and 165 of those lines are just removing the
 GNOME stuff from ./configure so that GTK 2 gets used instead of it. So here's
 how to use that diff. (Please don't ask me questions about this, I'm not
 supporting any of it, and especially, this is the BROKEN way of porting gaim, so
 I'm not taking bug reports.)
</p>
<?php end_section() ?>

<?php start_section("Step 1. Gtk 1.2.9") ?>
<p>
 You're going to have to install GTK 2 in order to use this patch, and if
 you don't want to completely fuck up your system, you're going to want to keep
 GTK 1.2 installed. GTK 1.2.9 has the nice properly that it can coexist with
 GTK 2; GTK 1.2.8 cannot. So make sure you're using 1.2.9 or higher (I'm actually
 using 1.2.10).
</p>
<?php end_section() ?>

<?php start_section("Step 2. pkg-config") ?>
<p>
 <a href="http://www.freedesktop.org/software/pkgconfig/">pkg-config</a> is the replacement
 for glib-config, gtk-config, et al. You'll need to install it before you can
 install GTK 2.
</p>
<?php end_section() ?>

<?php start_section("Step 3. Get glib, pango, atk, gtk+") ?>
<p>
 The patch isn't meant for GTK 1.3.5 (which is the last development release,
 AFAIK). There were changes to the GdkPixbuf API between 1.3.5 and what's
 currently in CVS, and this diff makes use of those changes. So get the glib,
 pango, and gtk+ modules out of GNOME's CVS. Do this by first logging in:
</p>

<p>
 <code>cvs -d :pserver:anonymous@anoncvs.gnome.org:/cvs/gnome login</code>
 <br /><font size=-1>Hit Enter at the password prompt</font>
</p>

<p>
 And then check out each module:
</p>

<p>
 <code>cvs -d :pserver:anonymous@anoncvs.gnome.org;/cvs/gnome co -r HEAD glib</code><br />
 <code>cvs -d :pserver:anonymous@anoncvs.gnome.org;/cvs/gnome co -r HEAD pango</code><br />
 <code>cvs -d :pserver:anonymous@anoncvs.gnome.org;/cvs/gnome co -r HEAD gtk+</code>
</p>
<?php end_section() ?>

<?php start_section("Step 4. Compile gtk+") ?>
<p>
 I'm not going to give real detailed directions for this, because you should
 be familiar with using software from CVS. But basically it's just the normal
 ./autogen.sh ; make ; make install. You need to have at least libtool 1.4
 installed though, and automake 1.4-p1 as well.
</p>
<?php end_section() ?>

<?php start_section("Step 5. Get gaim") ?>
<p>
 You should know how to do this by now. Directions are <a href="<?php
print $navigation["CVS Information"]["URL"] ?>">here</a>.
</p>
<?php end_section() ?>

<?php start_section("Step 6. Patch gaim") ?>
<p>
 OK, for those of you who have never applied a patch before, what you're
 going to do is this. Go to the top level of the Gaim CVS tree you just checked
 out. Then run
</p>

<p>
 <code>patch -p0 &lt;../path/to/broken.diff</code>
</p>

<p>
 Make sure to give the right path to the patch. The 'patch' program will then
 tell you which files it's patching, and how cleanly they applied.
</p>
<?php end_section() ?>

<?php start_section("Step 7. Compile gaim") ?>
<p>
 Now you just need to do the normal ./autogen.sh ; make that you do for your
 regular CVS tree. Have fun with it.
</p>
<?php end_section() ?>

<?php
	end_html();
?>
