#include <gtk/gtk.h>
#include "gtkimhtml.h"

static void deswin(GtkObject *o, gpointer d)
{
	gtk_widget_destroy(GTK_WIDGET(o));
}

static void newwin(GtkObject *o, gpointer d)
{
	GtkWidget *window;
	GtkWidget *sw;
	GtkWidget *imhtml;

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_signal_connect(GTK_OBJECT(window), "delete_event", deswin, NULL);

	sw = gtk_scrolled_window_new(NULL, NULL);
	gtk_container_add(GTK_CONTAINER(window), sw);

	imhtml = gtk_imhtml_new(NULL, NULL);
	gtk_container_add(GTK_CONTAINER(sw), imhtml);

	gtk_widget_show_all(window);
}

int main(int argc, char **argv)
{
	GtkWidget *window;
	GtkWidget *hbox;
	GtkWidget *button;

	gtk_init(&argc, &argv);

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_signal_connect(GTK_OBJECT(window), "delete_event",
			GTK_SIGNAL_FUNC(gtk_main_quit), NULL);

	hbox = gtk_hbox_new(TRUE, 5);
	gtk_container_add(GTK_CONTAINER(window), hbox);

	button = gtk_button_new_with_label("Open");
	gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 5);
	gtk_signal_connect(GTK_OBJECT(button), "clicked", newwin, NULL);

	button = gtk_button_new_with_label("Quit");
	gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 5);
	gtk_signal_connect(GTK_OBJECT(button), "clicked",
			GTK_SIGNAL_FUNC(gtk_main_quit), NULL);

	gtk_widget_show_all(window);

	gtk_main();
	return 0;
}
